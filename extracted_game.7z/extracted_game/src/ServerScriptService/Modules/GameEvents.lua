local Signal = require(game:GetService("ReplicatedStorage").Modules.Signal)
return {
	SheckleUpdate = Signal.new(),
	StealPlant = Signal.new()
}