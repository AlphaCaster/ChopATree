local InventoryService = {
	
}

return InventoryService
