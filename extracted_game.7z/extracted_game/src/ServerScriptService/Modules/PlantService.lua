local PlantService = {
	CollectPlant = function(self, player, plant)
		local playerData = self.PlayerData[player.UserId]
		
	end,
}

return PlantService
