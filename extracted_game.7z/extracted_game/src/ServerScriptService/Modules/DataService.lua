local module = {}

function module:GetPlayerDataAsync()
	return {}
end

return module
