-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v0 = {};
local l_Players_0 = game:GetService("Players");
local l_ReplicatedStorage_0 = game:GetService("ReplicatedStorage");
local _ = require(l_ReplicatedStorage_0.Modules.GuiController);
local _ = l_ReplicatedStorage_0:WaitForChild("GameEvents"):WaitForChild("UnlockTravellingMerchantEvent");
return v0;