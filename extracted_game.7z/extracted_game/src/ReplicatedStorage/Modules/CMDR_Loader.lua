-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local l_ReplicatedStorage_0 = game:GetService("ReplicatedStorage");
task.spawn(function() --[[ Line: 3 ]]
    -- upvalues: l_ReplicatedStorage_0 (copy)
    require(l_ReplicatedStorage_0:WaitForChild("CmdrClient")):SetActivationKeys({
        Enum.KeyCode.F2
    });
end);
return {};