-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

return {
    Name = "setweather", 
    Aliases = {
        "w"
    }, 
    Description = "Changes the weather to a specified type.", 
    Group = "GameCommands", 
    Args = {
        {
            Type = "weather", 
            Name = "weather", 
            Description = "The Seeds to give."
        }
    }
};