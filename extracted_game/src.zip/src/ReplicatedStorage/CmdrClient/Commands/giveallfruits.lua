-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

return {
    Name = "giveallfruits", 
    Aliases = {
        "gaf"
    }, 
    Description = "Gives all fruits to specified player(s).", 
    Group = "GameCommands", 
    Args = {
        {
            Type = "players", 
            Name = "to", 
            Description = "The player(s) to give fruits to."
        }
    }
};