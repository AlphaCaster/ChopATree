-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

return {
    {
        PLANT_NAME = "Tomato", 
        WEIGHT = 0.5, 
        MUTATION = nil, 
        VARIANT = nil
    }, 
    {
        PLANT_NAME = "Strawberry", 
        WEIGHT = 0.3, 
        MUTATION = nil, 
        VARIANT = nil
    }, 
    {
        PLANT_NAME = "Blueberry", 
        WEIGHT = 0.2, 
        MUTATION = nil, 
        VARIANT = nil
    }, 
    {
        PLANT_NAME = "Orange Tulip", 
        WEIGHT = 0.05, 
        MUTATION = nil, 
        VARIANT = nil
    }, 
    {
        PLANT_NAME = "Tomato", 
        WEIGHT = 0.5, 
        MUTATION = nil, 
        VARIANT = nil
    }, 
    {
        PLANT_NAME = "Corn", 
        WEIGHT = 2, 
        MUTATION = nil, 
        VARIANT = nil
    }, 
    {
        PLANT_NAME = "Daffodil", 
        WEIGHT = 0.22, 
        MUTATION = nil, 
        VARIANT = nil
    }, 
    {
        PLANT_NAME = "Strawberry", 
        WEIGHT = 0.35, 
        MUTATION = nil, 
        VARIANT = nil
    }, 
    {
        PLANT_NAME = "Blueberry", 
        WEIGHT = 0.25, 
        MUTATION = nil, 
        VARIANT = nil
    }, 
    {
        PLANT_NAME = "Bamboo", 
        WEIGHT = 4, 
        MUTATION = nil, 
        VARIANT = nil
    }, 
    {
        PLANT_NAME = "Carrot", 
        WEIGHT = 0.2, 
        MUTATION = "Wet", 
        VARIANT = nil
    }, 
    {
        PLANT_NAME = "Tomato", 
        WEIGHT = 0.55, 
        MUTATION = nil, 
        VARIANT = nil
    }, 
    {
        PLANT_NAME = "Corn", 
        WEIGHT = 3, 
        MUTATION = nil, 
        VARIANT = nil
    }, 
    {
        PLANT_NAME = "Watermelon", 
        WEIGHT = 7, 
        MUTATION = nil, 
        VARIANT = nil
    }, 
    {
        PLANT_NAME = "Pumpkin", 
        WEIGHT = 8, 
        MUTATION = nil, 
        VARIANT = nil
    }, 
    {
        PLANT_NAME = "Apple", 
        WEIGHT = 3, 
        MUTATION = nil, 
        VARIANT = nil
    }, 
    {
        PLANT_NAME = "Bamboo", 
        WEIGHT = 4.2, 
        MUTATION = nil, 
        VARIANT = nil
    }, 
    {
        PLANT_NAME = "Carrot", 
        WEIGHT = 0.25, 
        MUTATION = "Wet", 
        VARIANT = nil
    }, 
    {
        PLANT_NAME = "Strawberry", 
        WEIGHT = 0.32, 
        MUTATION = "Wet", 
        VARIANT = nil
    }, 
    {
        PLANT_NAME = "Daffodil", 
        WEIGHT = 0.22, 
        MUTATION = "Wet", 
        VARIANT = nil
    }, 
    {
        PLANT_NAME = "Tomato", 
        WEIGHT = 0.6, 
        MUTATION = nil, 
        VARIANT = nil
    }, 
    {
        PLANT_NAME = "Corn", 
        WEIGHT = 3.5, 
        MUTATION = nil, 
        VARIANT = nil
    }, 
    {
        PLANT_NAME = "Watermelon", 
        WEIGHT = 7.5, 
        MUTATION = nil, 
        VARIANT = nil
    }, 
    {
        PLANT_NAME = "Pumpkin", 
        WEIGHT = 8.5, 
        MUTATION = nil, 
        VARIANT = nil
    }, 
    {
        PLANT_NAME = "Blueberry", 
        WEIGHT = 0.22, 
        MUTATION = "Wet", 
        VARIANT = nil
    }, 
    {
        PLANT_NAME = "Orange Tulip", 
        WEIGHT = 0.06, 
        MUTATION = "Wet", 
        VARIANT = nil
    }, 
    {
        PLANT_NAME = "Tomato", 
        WEIGHT = 0.55, 
        MUTATION = "Chilled", 
        VARIANT = nil
    }, 
    {
        PLANT_NAME = "Corn", 
        WEIGHT = 2.2, 
        MUTATION = "Chilled", 
        VARIANT = nil
    }, 
    {
        PLANT_NAME = "Apple", 
        WEIGHT = 3.2, 
        MUTATION = "Wet", 
        VARIANT = nil
    }, 
    {
        PLANT_NAME = "Eggplant", 
        WEIGHT = 5, 
        MUTATION = nil, 
        VARIANT = nil
    }, 
    {
        PLANT_NAME = "Dragon Fruit", 
        WEIGHT = 12, 
        MUTATION = nil, 
        VARIANT = nil
    }, 
    {
        PLANT_NAME = "Carrot", 
        WEIGHT = 0.27, 
        MUTATION = "Chilled", 
        VARIANT = nil
    }, 
    {
        PLANT_NAME = "Blueberry", 
        WEIGHT = 0.2, 
        MUTATION = "Chilled", 
        VARIANT = nil
    }, 
    {
        PLANT_NAME = "Watermelon", 
        WEIGHT = 7.2, 
        MUTATION = "Wet", 
        VARIANT = nil
    }, 
    {
        PLANT_NAME = "Pumpkin", 
        WEIGHT = 8.2, 
        MUTATION = "Wet", 
        VARIANT = nil
    }, 
    {
        PLANT_NAME = "Bamboo", 
        WEIGHT = 4.5, 
        MUTATION = "Wet", 
        VARIANT = nil
    }, 
    {
        PLANT_NAME = "Coconut", 
        WEIGHT = 14.5, 
        MUTATION = "Wet", 
        VARIANT = nil
    }, 
    {
        PLANT_NAME = "Cactus", 
        WEIGHT = 7.2, 
        MUTATION = "Shocked", 
        VARIANT = nil
    }, 
    {
        PLANT_NAME = "Dragon Fruit", 
        WEIGHT = 12.2, 
        MUTATION = "Chilled", 
        VARIANT = nil
    }, 
    {
        PLANT_NAME = "Mango", 
        WEIGHT = 15.2, 
        MUTATION = "Wet", 
        VARIANT = nil
    }, 
    {
        PLANT_NAME = "Eggplant", 
        WEIGHT = 5.5, 
        MUTATION = "Shocked", 
        VARIANT = nil
    }, 
    {
        PLANT_NAME = "Bamboo", 
        WEIGHT = 4.7, 
        MUTATION = "Shocked", 
        VARIANT = nil
    }, 
    {
        PLANT_NAME = "Tomato", 
        WEIGHT = 0.6, 
        MUTATION = "Frozen", 
        VARIANT = nil
    }, 
    {
        PLANT_NAME = "Corn", 
        WEIGHT = 2.5, 
        MUTATION = "Wet", 
        VARIANT = nil
    }, 
    {
        PLANT_NAME = "Apple", 
        WEIGHT = 3.5, 
        MUTATION = "Wet", 
        VARIANT = nil
    }, 
    {
        PLANT_NAME = "Bamboo", 
        WEIGHT = 5, 
        MUTATION = "Frozen", 
        VARIANT = nil
    }, 
    {
        PLANT_NAME = "Dragon Fruit", 
        WEIGHT = 13, 
        MUTATION = "Chilled", 
        VARIANT = nil
    }, 
    {
        PLANT_NAME = "Mango", 
        WEIGHT = 16, 
        MUTATION = "Frozen", 
        VARIANT = nil
    }, 
    {
        PLANT_NAME = "Grape", 
        WEIGHT = 3.3, 
        MUTATION = "Shocked", 
        VARIANT = nil
    }, 
    {
        PLANT_NAME = "Coconut", 
        WEIGHT = 15, 
        MUTATION = "Wet", 
        VARIANT = nil
    }
};