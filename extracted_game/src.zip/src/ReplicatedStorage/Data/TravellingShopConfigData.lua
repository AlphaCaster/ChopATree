-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

return {
    RESET_TIME = 3600, 
    REQUIRED_WEIGHT = 30, 
    ROTATING_SHOP_SLOTS = 5
};