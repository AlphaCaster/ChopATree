-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

--local _ = require(script.Types);
return {
	Containers = require(script.QuestContainers),
	Rewards = require(script.QuestRewards),
	Quests = require(script.Quests)
};