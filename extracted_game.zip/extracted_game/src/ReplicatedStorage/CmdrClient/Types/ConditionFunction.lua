-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

return function(v0) --[[ Line: 1 ]]
    v0:RegisterType("conditionFunction", v0.Cmdr.Util.MakeEnumType("ConditionFunction", {
        "startsWith"
    }));
end;