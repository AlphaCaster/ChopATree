-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

return {
    Name = "tutorialvariant", 
    Args = {
        {
            Type = "players", 
            Name = "users", 
            Description = "The player(s) to start tutorial for"
        }, 
        {
            Type = "string", 
            Name = "Variant", 
            Description = "The variant to use"
        }
    }, 
    Description = "Sets the tutorial variant for the target user", 
    Group = "GameCommands"
};