-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

return {
    Name = "wipeself", 
    Args = {}, 
    Description = "Wipes the user of the command", 
    Group = "GameCommands"
};