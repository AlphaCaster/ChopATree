-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

return {
    Name = "giveallseeds", 
    Aliases = {
        "gas"
    }, 
    Description = "Gives all seeds to specified player(s).", 
    Group = "GameCommands", 
    Args = {
        {
            Type = "players", 
            Name = "to", 
            Description = "The player(s) to give seeds to."
        }
    }
};