-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

return {
    Timer = {
        {
            Time = 0, 
            Luck = 0.1
        }, 
        {
            Time = 300, -- 300 
            Luck = 0.25
        }, 
        {
            Time = 600, 
            Luck = 0.5
        }, 
        {
            Time = 1500, 
            Luck = 1
        }, 
        {
            Time = 2700, 
            Luck = 2
        }, 
        {
            Time = 4500, 
            Luck = 3
        }
    }
};