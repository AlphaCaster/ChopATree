-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local l_ReplicatedStorage_0 = game:GetService("ReplicatedStorage");
--local _ = require(l_ReplicatedStorage_0.Data.QuestData.Types);
local v2 = {
    EarnSheckles = require(script.EarnSheckles), 
    Plant = require(script.Plant), 
    Harvest = require(script.Harvest), 
    PlayTime = require(script.PlayTime)
};
return (table.freeze(v2));